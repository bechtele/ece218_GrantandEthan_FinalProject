//=====[#include guards - begin]===============================================

#ifndef _BRAKE_LIGHT_H_
#define _BRAKE_LIGHT_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void brakelightInit();
void brakelightUpdate();

//=====[#include guards - end]=================================================

#endif // _BRAKE_LIGHT_H_