//=====[#include guards - begin]===============================================

#ifndef _DEBOUNCE_H_
#define _DEBOUNCE_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

//=====[#include guards - end]=================================================

#endif // _DEBOUNCE_H_