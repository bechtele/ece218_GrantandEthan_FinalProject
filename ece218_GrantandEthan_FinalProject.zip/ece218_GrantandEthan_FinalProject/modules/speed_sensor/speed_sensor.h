//=====[#include guards - begin]===============================================

#ifndef _SPEED_SENSOR_H_
#define _SPEED_SENSOR_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void speedsensorInit();
void speedsensorUpdate();

//=====[#include guards - end]=================================================

#endif // _SPEED_SENSOR_H_